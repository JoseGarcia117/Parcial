﻿using BienestarUniversitario.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.IO;

namespace BienestarUniversitario.Logic
{
    internal class StudentServices
    {
        private readonly Data.StudentRepository StudentRepository;
        List<Student> studentList;
        public StudentServices()
        {
            StudentRepository = new Data.StudentRepository("Estudiantes.txt");
        }

        public bool AddStudent(Student student)
        {
            return StudentRepository.Save(student);
        }

        public Student GetByID(int id)
        {
            if (File.Exists("Estudiantes.txt"))
            {
                studentList = StudentRepository.Read();
                return studentList.FirstOrDefault(Student => Student.Id == id);
            }
            else
            {
                return null;
            }
        }
    }
}
