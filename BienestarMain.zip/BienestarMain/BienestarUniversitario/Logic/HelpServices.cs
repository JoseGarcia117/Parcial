﻿using BienestarUniversitario.Entity;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BienestarUniversitario.Logic
{
    internal class HelpServices
    {
        private readonly Data.HelpsRepository HelpsRepository;
        List<HelpType> helpsList;
        public HelpServices()
        {
            HelpsRepository = new Data.HelpsRepository("TipoAyuda.txt");
        }

        public bool AddHelp(HelpType helps)
        {
            return HelpsRepository.Save(helps);
        }

        public List<HelpType> HelpsRead() 
        { 
            return HelpsRepository.Read();
        }

        public HelpType GetByCode(int code)
        {
            if (File.Exists("TipoAyuda.txt"))
            {
                helpsList = HelpsRepository.Read();
                return helpsList.FirstOrDefault(HelpType => HelpType.Code == code);
            }
            else
            {
                return null;
            }
        }
    }
}
