﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BienestarUniversitario.Logic
{
    internal interface ICrud<T>
    {
        void Create(T entidad);
        List<T> GetAll();
        void Update(T entidad);
        void Delete(int id);
        T GetById(int id);
        T GetByCode(int code);
    }
}
