﻿using BienestarUniversitario.Entity;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BienestarUniversitario.Data
{
    internal class HelpsRepository : BaseRepository<HelpType>
    {
        public HelpsRepository(string fileName) : base(fileName) { }
        public List<HelpType> Read()
        {
            try
            {
                string line;
                List<HelpType> helpsList = new List<HelpType>();
                StreamReader reader = new StreamReader(fileName);
                while (!reader.EndOfStream)
                {
                    line = reader.ReadLine();
                    helpsList.Add(Map(line));
                }
                reader.Close();
                return helpsList;
            }
            catch (Exception)
            {
                return null;
            }

            HelpType Map(string line)
            {
                HelpType help = new HelpType();
                var vector = line.Split(';');
                help.Code = int.Parse(vector[0]);
                help.Name = vector[1];
                help.NumBenefited = int.Parse(vector[2]);
                return help;
            }
        }
    }
}
