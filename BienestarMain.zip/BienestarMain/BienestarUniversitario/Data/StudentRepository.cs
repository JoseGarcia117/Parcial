﻿using BienestarUniversitario.Entity;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BienestarUniversitario.Data
{
    internal class StudentRepository : BaseRepository<Student>
    {
        public StudentRepository(string fileName) : base(fileName) { }

        public List<Student> Read()
        {
            try
            {
                string line;
                List<Student> studentList = new List<Student>();
                StreamReader reader = new StreamReader(fileName);
                while (!reader.EndOfStream)
                {
                    line = reader.ReadLine();
                    studentList.Add(Map(line));
                }
                reader.Close();
                return studentList;
            }
            catch (Exception)
            {
                return null;
            }
        }

        Student Map(string line)
        {
            Student student = new Student();
            var vector = line.Split(';');
            student.Id = int.Parse(vector[0]);
            student.Name = vector[1];
            student.Benefed = bool.Parse(vector[2]);
            return student;
        }
    }
}
