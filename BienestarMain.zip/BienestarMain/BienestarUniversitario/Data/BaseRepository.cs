﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BienestarUniversitario.Data
{
    internal class BaseRepository<T>
    {
        protected string fileName = string.Empty;
        protected BaseRepository(string fileName)
        {
            this.fileName = fileName;
        }

        public bool Save(T entidad)
        {
            try
            {
                StreamWriter writer = new StreamWriter(fileName, true);
                writer.WriteLine(entidad.ToString());
                writer.Close();
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            }

        }
    }
}
