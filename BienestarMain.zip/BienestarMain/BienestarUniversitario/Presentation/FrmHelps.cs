﻿using BienestarUniversitario.Entity;
using BienestarUniversitario.Logic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BienestarUniversitario.Presentation
{
    public partial class FrmHelps : Form
    {
        Logic.HelpServices helpServices;
        public FrmHelps()
        {
            InitializeComponent();
            helpServices = new Logic.HelpServices();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            
        }

        void Guardar()
        {
            
        }
    }
}
