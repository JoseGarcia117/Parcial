﻿namespace BienestarUniversitario.Presentation
{
    partial class FrmMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnStudents = new System.Windows.Forms.Button();
            this.btnHelps = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnBack);
            this.panel1.Controls.Add(this.btnHelps);
            this.panel1.Controls.Add(this.btnStudents);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(803, 452);
            this.panel1.TabIndex = 0;
            // 
            // btnStudents
            // 
            this.btnStudents.Location = new System.Drawing.Point(280, 83);
            this.btnStudents.Name = "btnStudents";
            this.btnStudents.Size = new System.Drawing.Size(213, 58);
            this.btnStudents.TabIndex = 0;
            this.btnStudents.Text = "Estudiantes";
            this.btnStudents.UseVisualStyleBackColor = true;
            // 
            // btnHelps
            // 
            this.btnHelps.Location = new System.Drawing.Point(280, 175);
            this.btnHelps.Name = "btnHelps";
            this.btnHelps.Size = new System.Drawing.Size(213, 58);
            this.btnHelps.TabIndex = 1;
            this.btnHelps.Text = "Ayudas";
            this.btnHelps.UseVisualStyleBackColor = true;
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(280, 260);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(213, 58);
            this.btnBack.TabIndex = 2;
            this.btnBack.Text = "Salir";
            this.btnBack.UseVisualStyleBackColor = true;
            // 
            // FrmMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel1);
            this.Name = "FrmMenu";
            this.Text = "MenúGUIcs";
            this.Load += new System.EventHandler(this.MenúGUIcs_Load);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnHelps;
        private System.Windows.Forms.Button btnStudents;
    }
}